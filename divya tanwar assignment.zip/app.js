
const express = require('express')
const app=express()
const frontendRouter =require('./routers/frontend');
const mongoose =require('mongoose')
app.use(express.urlencoded({extended:false}));
mongoose.connect ("mongodb://127.0.0.1:27017/newproject",()=>{console.log("connected to database newproject..")})

app.use(frontendRouter);

app.set('view engine','ejs');
app.listen(5000,()=>{console.log('server is runnibg on port 5000')});