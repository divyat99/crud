
const router=require('express').Router();
const student = require('../models/student');


router.get('/',(req,res)=>{
    res.render('form.ejs',{mess:''})
})


router.post('/formrecords',(req,res)=>{
    const name=req.body.firstname
    const addd=req.body.add
    const rollno=req.body.roll;
    //console.log(firstname,addd,rollno)
const studentrecord=new student({name:name,address:addd,rollno:rollno})
studentrecord.save()
res.render('form.ejs',{mess:'data sumbitted'})
})
router.get('/singlefetch',async(req,res)=>{
    const studentrecord =await student.findOne()
    console.log(studentrecord);
    res.render('fetchsingle',{studentRecord:studentrecord})
    
})
router.get('/fetch',async(req,res)=>{
    const studentrecords =await student.find()
    console.log(studentrecords);
    res.render('fetch.ejs',{studentrecords})
    
})
// router.get('/update/:id',(req,res)=>{
//     console.log(req.params.id)
//     res.render('updateform.ejs')
// })
router.get('/update/:id',async(req,res)=>{
    const students = await student.findById(req.params.id)
    // console.log(students)
    res.render('updateform.ejs',{students})
})
router.post('/updaterecord/:id',async(req,res)=>{
    const id=req.params.id
    const firstname =req.body.firstname
    const address= req.body.add
    const rollno=req.body.roll
    // console.log(req.params.id,req.body)
    console.log(req.body)
    await student.findByIdAndUpdate(id,{name:firstname,address:address,rollno:rollno})
    res.redirect('/fetch')
})
router.get('/delete/:xyz',async(req,res)=>{
    const abc=req.params.xyz
    await student.findByIdAndDelete(abc)
    res.redirect('/fetch')
    //console.log(req.params.xyz);
})
module.exports =router;