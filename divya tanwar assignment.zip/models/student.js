const mongoose=require('mongoose')

const studentSchema=mongoose.Schema({
    name:String ,
    address:String,
    rollno:Number
});

module.exports = mongoose.model('student',studentSchema)
